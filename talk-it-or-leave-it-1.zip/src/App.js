// src/App.js
import React, { useState } from "react";

const allQuestions = [
  "Was war dein peinlichstes Erlebnis?",
  "Wenn du eine Superkraft haben könntest – welche wäre es?",
  "Mit welcher berühmten Person würdest du gerne einen Tag verbringen?",
  "Was war dein letzter Lachanfall?",
  "Was würdest du tun, wenn du einen Tag lang unsichtbar wärst?",
  "Was ist deine geheime Macke?",
  "Wovor hast du Angst, obwohl es irrational ist?",
  "Was war dein schlimmster Fehlkauf?",
  "Welche App benutzt du heimlich zu viel?",
  "Was würdest du nie vor deinen Eltern zugeben?",
  "Was ist dein seltsamstes Hobby?",
  "Wofür schämst du dich ein bisschen, obwohl du es magst?",
  "Mit wem würdest du gerne für einen Tag das Leben tauschen?",
  "Welche Serienfigur beschreibt dich am besten?",
  "Was war dein größter Fail beim Flirten?",
  "Was ist das Mutigste, das du je gemacht hast?",
  "Was würdest du tun, wenn du heute 1 Million Euro bekommst?",
  "Was ist das Dümmste, das du je geglaubt hast?",
  "Was nervt dich heimlich an deinen Freunden?",
  "Welche Regel würdest du abschaffen, wenn du könntest?",
  "Welche drei Dinge würdest du auf eine einsame Insel mitnehmen?",
  "Welches Geheimnis hast du noch nie jemandem erzählt?",
  "Was war dein lustigster Traum?",
  "Was ist das Unnötigste, das du je gekauft hast?",
  "Was würdest du deinem jüngeren Ich raten?",
  "Welches Lied kannst du heimlich auswendig mitsingen?",
  "Wenn du ein Tier wärst, welches wärst du und warum?",
  "Was war dein schlimmster Modetrend?",
  "Womit hast du mal richtig übertrieben?",
  "Was war das Dümmste, das du je in der Schule gemacht hast?"
];

function shuffle(array) {
  let currentIndex = array.length, randomIndex;
  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
  }
  return array;
}

export default function App() {
  const [shuffledQuestions, setShuffledQuestions] = useState(shuffle([...allQuestions]));
  const [currentIndex, setCurrentIndex] = useState(0);

  const newQuestion = () => {
    if (currentIndex + 1 >= shuffledQuestions.length) {
      setShuffledQuestions(shuffle([...allQuestions]));
      setCurrentIndex(0);
    } else {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-br from-pink-100 to-blue-100">
      <div className="bg-white p-6 rounded-2xl shadow-xl text-center max-w-md w-full">
        <h1 className="text-2xl font-bold mb-1">🎉 Talk It or Leave It 🎉</h1>
        <h2 className="text-md text-gray-600 mb-4">von Rares Lazar</h2>
        <p className="mb-6 text-lg">{shuffledQuestions[currentIndex]}</p>
        <button
          onClick={newQuestion}
          className="bg-blue-500 text-white px-4 py-2 rounded-xl hover:bg-blue-600 transition"
        >
          Neue Frage
        </button>
      </div>
    </div>
  );
}
